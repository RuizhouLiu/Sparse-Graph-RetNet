import os
import sys

import yaml
import argparse
import torch
import shutil
import torch.nn as nn
from torch.utils.data import DataLoader
import torch.nn.functional as F
import numpy as np
from tqdm import tqdm
import logging
import random
from torch.utils.tensorboard import SummaryWriter

from src.utils import Config, get_dir, to_triplets, to_device
from src.datasets_utils import get_heterophilic_dataset_IDM, TripletDataset, ChainDataset
from src.model import PEModel, Undirected_SimplePE, UndirectedPE


args_parser = argparse.ArgumentParser(description="RetNet for Graphs")
args_parser.add_argument(
    "--config_path", default=None
)
input_arg = args_parser.parse_args()

def main():
    if input_arg.config_path is None:
        config_file = "./config/cornell_config.yaml"
    else:
        config_file = input_arg.config_path
    
    args = Config(config_file).get()
    log_dir, save_dir = get_dir(os.path.join(args.log_dir, args.dataset_name), os.path.join(args.save_dir, args.dataset_name))
    writer = SummaryWriter(log_dir=log_dir, comment=args.dataset_name)

    if not os.path.exists(save_dir):
        os.makedirs(save_dir, exist_ok=True)
    # prepareing logger
    logging.basicConfig(
        format="%(asctime)s %(levelname)-8s %(message)s",
        level=logging.INFO,
        datefmt="%Y-%m-%d %H:%M:%S",
        filename=os.path.join(save_dir, "train.log")
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s %(levelname)-8s %(message)s")
    console.setFormatter(formatter)
    logging.getLogger("").addHandler(console)
    logging.info("Saving logs in: {}".format(save_dir))
    logging.info(f"dataset is {args.dataset_name}")
    # prepareing logger

    # copying code and configs
    folder_path = os.path.split(os.path.abspath(__file__))[0]
    shutil.copytree(os.path.join(folder_path, "src"), os.path.join(save_dir, "code", "src"))
    shutil.copytree(os.path.join(folder_path, "config"), os.path.join(save_dir, "code", "config"))

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.device != 'cpu':
        torch.cuda.manual_seed(args.seed)
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    torch.backends.cudnn.enabled = True
    
    device = f'cuda:{args.device}' if torch.cuda.is_available() and args.device != 'cpu' else 'cpu'

    # raw_adj, sp_adj, features, labels, idx_train, idx_val, idx_test, is_undirected = get_heterophilic_dataset_IDM(args.dataset_name, args.data_path, args.idx_split, device=device)
    dataset = TripletDataset(args.data_path, args.dataset_name, args.num_neg, device=device)
    train_set = dataset.train_set
    test_set = dataset.test_set
    is_undirected = dataset.is_undirected
    
    if args.dataset_name == 'chain':
        np.save(os.path.join(save_dir, 'triplets.npy'), dataset.triplets)
    
    train_loader = DataLoader(train_set, batch_size=args.batch_size, collate_fn=train_set.collate_fn, num_workers=args.num_workers)
    test_loader = DataLoader(test_set, batch_size=10, collate_fn=test_set.collate_fn)

    if not is_undirected:
        model = PEModel(dataset.num_ent, dataset.num_rel, args.rank, x_rank=args.x_rank, phi_rank=args.phi_rank, reg_weight=args.regularization_weight, margin=args.margin, epsilon=args.epsilon)
    else:
        # model = Undirected_SimplePE(dataset.num_ent, rank=args.rank)
        # model = UndirectedPE(dataset.num_ent, dataset.num_rel, rank=args.rank)
        model = PEModel(dataset.num_ent, dataset.num_rel, args.rank, x_rank=args.x_rank, phi_rank=args.phi_rank, reg_weight=args.regularization_weight, margin=args.margin, epsilon=args.epsilon)
    model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)

    # training & validating
    counter = 0
    best_mrr = None
    best_epoch = None
    for ep_i in range(args.epochs):
        model.train()
        
        tot_loss = 0.0
        for batch_idx, batch_data in enumerate(train_loader):
            batch_data = to_device(batch_data, device=device)
            loss = model(batch_data)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            tot_loss += loss.item()
        
        logging.info(f'Epoch: {ep_i}\ttraining loss: {tot_loss / (batch_idx + 1):.4f}')

        
        if (ep_i + 1) % args.valid_period == 0:
            model.eval()
            all_ranks = []
            test_metrics = {}
            for batch_data in test_loader:
                to_device(batch_data, device=device)
                bz_ranks = model.test_one_step(batch_data)
                all_ranks.extend(bz_ranks)
            
            all_ranks = torch.tensor(all_ranks)
            test_metrics["count"] = torch.numel(all_ranks)
            test_metrics["mrr"] = torch.mean(1.0 / all_ranks).item()
            test_metrics["mr"] = torch.mean(all_ranks).item()
            for k in [1, 3, 10]:    # hit @ k, k = [1,3,10]
                test_metrics['hits@{}'.format(k)] = torch.numel(all_ranks[all_ranks <= k]) / test_metrics["count"]
            
            logging.info(f'Epoch: {ep_i}\tMR: {test_metrics["mr"]:.4f}, MRR: {test_metrics["mrr"]:.4f}, Hits@1: {test_metrics["hits@1"]:.4f}, Hits@3: {test_metrics["hits@3"]:.4f}, Hits@10: {test_metrics["hits@10"]:.4f}')

            test_mrr = test_metrics["mrr"]
            if not best_mrr or test_mrr > best_mrr:
                best_mrr = test_mrr
                counter = 0
                best_epoch = ep_i + 1
                logging.info("\t Saving model at epoch {} in {}".format(ep_i + 1, save_dir))
                torch.save(model.state_dict(), os.path.join(save_dir, "model.pt"))
            else:
                counter += 1
                if counter == args.patience:
                    logging.info("\t Early stopping")
                    break
    
    logging.info("\t Optimization finished")
    if not best_mrr:
        torch.save(model.state_dict(), os.path.join(save_dir, "model.pt"))
    else:
        logging.info("\t Loading best model saved at epoch {}".format(best_epoch))
        model.load_state_dict(torch.load(os.path.join(save_dir, "model.pt")))
    model.to(device)
    model.eval()


    model.eval()
    all_ranks = []
    test_metrics = {}
    for batch_data in test_loader:
        to_device(batch_data, device=device)
        bz_ranks = model.test_one_step(batch_data)
        all_ranks.extend(bz_ranks)
    
    all_ranks = torch.tensor(all_ranks)
    test_metrics["count"] = torch.numel(all_ranks)
    test_metrics["mrr"] = torch.mean(1.0 / all_ranks).item()
    test_metrics["mr"] = torch.mean(all_ranks).item()
    for k in [1, 3, 10]:    # hit @ k, k = [1,3,10]
        test_metrics['hits@{}'.format(k)] = torch.numel(all_ranks[all_ranks <= k]) / test_metrics["count"]
    
    logging.info(f'Testing:  MR: {test_metrics["mr"]:.4f}, MRR: {test_metrics["mrr"]:.4f}, Hits@1: {test_metrics["hits@1"]:.4f}, Hits@3: {test_metrics["hits@3"]:.4f}, Hits@10: {test_metrics["hits@10"]:.4f}')


            

        


if __name__ == "__main__":
    main()