import sys
import os
import numpy as np
import scipy.sparse as sp
from torch.utils.data import Dataset
from collections import defaultdict as ddict
from typing import Callable, List, Optional

from torch_geometric.data import InMemoryDataset
from torch_geometric.io import fs, read_planetoid_data

import torch
# import torch_sparse
import pickle as pkl
import networkx as nx
from .normalization import fetch_normalization, row_normalize, aug_normalized_adjacency
from time import perf_counter
# import ipdb
from .utils import *

import os.path as osp
from torch_sparse import coalesce, SparseTensor
from torch_geometric.data import InMemoryDataset, download_url, Data
from torch_geometric.utils.undirected import is_undirected, to_undirected
from torch_geometric.utils import to_networkx
import torch_geometric.transforms as T

from sklearn import metrics

def get_balanced_random_split(one_hot_labels, num_classes, percls_trn=20, val_lb=500):
    indices = []
    labels = np.argmax(one_hot_labels, axis=1)
    for i in range(num_classes):
        index = np.nonzero(labels==i)[0]
        # print(f'i: {i}, index: {index}')
        index = np.random.permutation(index)
        indices.append(index)
    # print([i[:percls_trn] for i in indices])
    train_index = np.concatenate([i[:percls_trn] for i in indices])
    # print(f'train_index: {train_index}')
    rest_index = np.concatenate([i[percls_trn:] for i in indices])
    rest_index = np.random.permutation(rest_index)
    # print(f'rest_index: {rest_index}')
    val_index = rest_index[:val_lb]
    test_index = rest_index[val_lb:]
    return train_index, val_index, test_index


def load_citation_syn_chain_IDM(normalization, cuda, num_chains, chain_len, num_class=2,
                                noise=0.00, noise_type=None, need_orig=False):
    """load the synthetic dataset: chain"""
    # r = np.random.RandomState(42)
    c = num_class # num of classes
    n = num_chains # chains for each class
    l = chain_len # length of chain
    f = 100 # feature dimension
    # tn = 20  # train nodes
    # vl = 100 # val nodes
    # tt = 200 # test nodes
    num_nodes = c*n*l
    tn = int(num_nodes*0.05)
    vl = int(num_nodes*0.1)
    tt = num_nodes - tn - vl
    noise = noise

    # directed chains
    chain_adj = sp.coo_matrix((np.ones(l-1), (np.arange(l-1), np.arange(1, l))), shape=(l, l))
    adj = sp.block_diag([chain_adj for _ in range(c*n)]) # square matrix N = c*n*l

    # features = r.uniform(-noise, noise, size=(c, n, l, f))
    if noise_type is None:
        features = np.random.uniform(-noise, noise, size=(c,n,l,f))
    elif noise_type == 'normal':
        features = np.random.normal(0, noise, size=(c,n,l,f))
    elif noise_type == 'normal_v2':
        features = np.random.normal(0, 1, size=(c,n,l,f)) * noise
    else:
        raise RuntimeError(f'Cannot find noise type {noise_type}')
    #features = np.zeros_like(features)
    features[:, :, 0, :c] += np.eye(c).reshape(c, 1, c) # add class info to the first node of chains.
    features = features.reshape(-1, f)

    labels = np.eye(c).reshape(c, 1, 1, c).repeat(n, axis=1).repeat(l, axis=2) # one-hot labels
    labels = labels.reshape(-1, c)
    # ipdb.set_trace()

    idx_random = np.arange(c*n*l)
    # r.shuffle(idx_random)
    np.random.shuffle(idx_random)
    idx_train = idx_random[:tn]
    idx_val = idx_random[tn:tn+vl]
    idx_test = idx_random[tn+vl:tn+vl+tt]
    print(f'idx_train: {len(idx_train)}, idx_val: {len(idx_val)}, idx_test: {len(idx_test)}')
    # print(f'idx_train: {idx_train}')
    print(f'features[0,:10]: {features[0,:10]}')
    print(f'features[1,:10]: {features[1,:10]}')

    if need_orig:
        adj_orig = aug_normalized_adjacency(adj, need_orig=True)
        adj_orig = sparse_mx_to_torch_sparse_tensor(adj_orig).float()
        if cuda:
            adj_orig = adj_orig.cuda()

    # adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    norm_adj, features = preprocess_citation(adj, features, normalization)
    # porting to pytorch
    features = torch.FloatTensor(np.array(features.todense() if sp.issparse(features) else features)).float()
    labels = torch.LongTensor(labels)
    labels = torch.max(labels, dim=1)[1]
    raw_adj = sparse_mx_to_torch_sparse_tensor(adj).float()
    norm_adj = sparse_mx_to_torch_sparse_tensor(norm_adj).float()
    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)
    is_undirected = False

    if cuda:
        features = features.cuda()
        raw_adj = raw_adj.cuda()
        norm_adj = norm_adj.cuda()
        labels = labels.cuda()
        idx_train = idx_train.cuda()
        idx_val = idx_val.cuda()
        idx_test = idx_test.cuda()

    return raw_adj, norm_adj, features, labels, idx_train, idx_val, idx_test, is_undirected


def load_citation_syn_chain(normalization, cuda, num_chains, chain_len, num_class=2, noise=0.00,
                            noise_type=None, need_orig=False):
    """load the synthetic dataset: chain"""
    c = num_class # num of classes
    n = num_chains # chains for each class
    l = chain_len # length of chain
    f = 100 # feature dimension
    num_nodes = c*n*l
    tn = int(num_nodes*0.05)
    vl = int(num_nodes*0.1)
    tt = num_nodes - tn - vl
    noise = noise

    chain_adj = sp.coo_matrix((np.ones(l-1), (np.arange(l-1), np.arange(1, l))), shape=(l, l))
    adj = sp.block_diag([chain_adj for _ in range(c*n)]) # square matrix N = c*n*l

    # features = r.uniform(-noise, noise, size=(c, n, l, f))
    # features = np.random.uniform(-noise, noise, size=(c,n,l,f))
    if noise_type is None:
        features = np.random.uniform(-noise, noise, size=(c,n,l,f))
    elif noise_type == 'normal':
        features = np.random.normal(0, noise, size=(c,n,l,f))
    elif noise_type == 'normal_v2':
        features = np.random.normal(0, 1, size=(c,n,l,f)) * noise
    else:
        raise RuntimeError(f'Cannot find noise type {noise_type}')
    #features = np.zeros_like(features)
    features[:, :, 0, :c] += np.eye(c).reshape(c, 1, c) # add class info to the first node of chains.
    features = features.reshape(-1, f)

    labels = np.eye(c).reshape(c, 1, 1, c).repeat(n, axis=1).repeat(l, axis=2) # one-hot labels
    labels = labels.reshape(-1, c)
    idx_random = np.arange(c*n*l)
    # r.shuffle(idx_random)
    np.random.shuffle(idx_random)
    idx_train = idx_random[:tn]
    idx_val = idx_random[tn:tn+vl]
    idx_test = idx_random[tn+vl:tn+vl+tt]
    print(f'idx_train: {len(idx_train)}, idx_val: {len(idx_val)}, idx_test: {len(idx_test)}')
    print(f'labels of idx_train: {labels[idx_train, :]}')
    # print(f'idx_train: {idx_train}')
    print(f'features[0,:10]: {features[0,:10]}')

    if need_orig:
        adj_orig = aug_normalized_adjacency(adj, need_orig=True)
        adj_orig = sparse_mx_to_torch_sparse_tensor(adj_orig).float()
        if cuda:
            adj_orig = adj_orig.cuda()

    # adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    adj, features = preprocess_citation(adj, features, normalization)

    # porting to pytorch
    features = torch.FloatTensor(np.array(features.todense() if sp.issparse(features) else features)).float()
    labels = torch.LongTensor(labels)
    labels = torch.max(labels, dim=1)[1]
    adj = sparse_mx_to_torch_sparse_tensor(adj).float()
    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)

    if cuda:
        features = features.cuda()
        adj = adj.cuda()
        labels = labels.cuda()
        idx_train = idx_train.cuda()
        idx_val = idx_val.cuda()
        idx_test = idx_test.cuda()

    return [adj, adj_orig] if need_orig else adj, features, labels, idx_train, idx_val, idx_test


class WebKB_new(InMemoryDataset):
    r"""The WebKB datasets used in the
    `"Geom-GCN: Geometric Graph Convolutional Networks"
    <https://openreview.net/forum?id=S1e2agrFvS>`_ paper.
    Nodes represent web pages and edges represent hyperlinks between them.
    Node features are the bag-of-words representation of web pages.
    The task is to classify the nodes into one of the five categories, student,
    project, course, staff, and faculty.
    Args:
        root (string): Root directory where the dataset should be saved.
        name (string): The name of the dataset (:obj:`"Cornell"`,
            :obj:`"Texas"` :obj:`"Wisconsin"`).
        transform (callable, optional): A function/transform that takes in an
            :obj:`torch_geometric.data.Data` object and returns a transformed
            version. The data object will be transformed before every access.
            (default: :obj:`None`)
        pre_transform (callable, optional): A function/transform that takes in
            an :obj:`torch_geometric.data.Data` object and returns a
            transformed version. The data object will be transformed before
            being saved to disk. (default: :obj:`None`)
    """

    url = 'https://raw.githubusercontent.com/graphdml-uiuc-jlu/geom-gcn/master'

    def __init__(self, root, name, transform=None, pre_transform=None):
        self.name = name.lower()
        assert self.name in ['cornell', 'texas', 'wisconsin', 'film']

        super(WebKB_new, self).__init__(root, transform, pre_transform)
        self.data, self.slices = torch.load(self.processed_paths[0])
        self.is_undirected = True

    @property
    def raw_dir(self):
        return osp.join(self.root, self.name, 'raw')

    @property
    def processed_dir(self):
        return osp.join(self.root, self.name, 'processed')

    @property
    def raw_file_names(self):
        return ['out1_node_feature_label.txt', 'out1_graph_edges.txt'] + [
            '{}_split_0.6_0.2_{}.npz'.format(self.name, i) for i in range(10)
        ]

    @property
    def processed_file_names(self):
        return 'data.pt'

    def download(self):
        for f in self.raw_file_names[:2]:
            # download_url(f'{self.url}/new_data/{self.name}/{f}', self.raw_dir)
            print(f'{self.url}/new_data/{self.name}/{f}')
        for f in self.raw_file_names[2:]:
            # download_url(f'{self.url}/splits/{f}', self.raw_dir)
            print(f'{self.url}/splits/{f}')

        # print()

    def process(self):
        with open(self.raw_paths[0], 'r') as f:
            data = f.read().split('\n')[1:-1]
            x = [[float(v) for v in r.split('\t')[1].split(',')] for r in data]
            x = torch.tensor(x, dtype=torch.float)

            y = [int(r.split('\t')[2]) for r in data]
            y = torch.tensor(y, dtype=torch.float)

        with open(self.raw_paths[1], 'r') as f:
            data = f.read().split('\n')[1:-1]
            data = [[int(v) for v in r.split('\t')] for r in data]
            edge_index = torch.tensor(data, dtype=torch.long).t().contiguous()
            edge_index = to_undirected(edge_index)
            self.is_undirected = True
            edge_index, _ = coalesce(edge_index, None, x.size(0), x.size(0))

        train_masks, val_masks, test_masks = [], [], []
        for f in self.raw_paths[2:]:
            tmp = np.load(f)
            train_masks += [torch.from_numpy(tmp['train_mask']).to(torch.bool)]
            val_masks += [torch.from_numpy(tmp['val_mask']).to(torch.bool)]
            test_masks += [torch.from_numpy(tmp['test_mask']).to(torch.bool)]
        train_mask = torch.stack(train_masks, dim=1)
        val_mask = torch.stack(val_masks, dim=1)
        test_mask = torch.stack(test_masks, dim=1)
        data = Data(x=x, edge_index=edge_index, y=y, train_mask=train_mask,
                    val_mask=val_mask, test_mask=test_mask)
        data = data if self.pre_transform is None else self.pre_transform(data)
        torch.save(self.collate([data]), self.processed_paths[0])

    def __repr__(self):
        return '{}()'.format(self.name)


class WikipediaNetwork(InMemoryDataset):
    r"""The Wikipedia networks used in the
    `"Geom-GCN: Geometric Graph Convolutional Networks"
    <https://openreview.net/forum?id=S1e2agrFvS>`_ paper.
    Nodes represent web pages and edges represent hyperlinks between them.
    Node features represent several informative nouns in the Wikipedia pages.
    The task is to classify the nodes into five categories in term of the
    number of average monthly traffic of the web page.

    Args:
        root (string): Root directory where the dataset should be saved.
        name (string): The name of the dataset (:obj:`"Chameleon"`,
            :obj:`"Squirrel"`).
        transform (callable, optional): A function/transform that takes in an
            :obj:`torch_geometric.data.Data` object and returns a transformed
            version. The data object will be transformed before every access.
            (default: :obj:`None`)
        pre_transform (callable, optional): A function/transform that takes in
            an :obj:`torch_geometric.data.Data` object and returns a
            transformed version. The data object will be transformed before
            being saved to disk. (default: :obj:`None`)
    """

    url = 'https://raw.githubusercontent.com/graphdml-uiuc-jlu/geom-gcn/master'

    def __init__(self, root, name, transform=None, pre_transform=None):
        self.name = name.lower()
        assert self.name in ['chameleon', 'squirrel']

        super(WikipediaNetwork, self).__init__(root, transform, pre_transform)
        self.data, self.slices = torch.load(self.processed_paths[0])
        self.is_undirected = False

    @property
    def raw_dir(self):
        return osp.join(self.root, self.name, 'raw')

    @property
    def processed_dir(self):
        return osp.join(self.root, self.name, 'processed')

    @property
    def raw_file_names(self):
        return ['out1_node_feature_label.txt', 'out1_graph_edges.txt'] + [
            '{}_split_0.6_0.2_{}.npz'.format(self.name, i) for i in range(10)
        ]

    @property
    def processed_file_names(self):
        return 'data.pt'

    def download(self):
        for f in self.raw_file_names[:2]:
            # download_url(f'{self.url}/new_data/{self.name}/{f}', self.raw_dir)
            print(f'{self.url}/new_data/{self.name}/{f}')
        for f in self.raw_file_names[2:]:
            # download_url(f'{self.url}/splits/{f}', self.raw_dir)
            print(f'{self.url}/splits/{f}')

    def process(self):
        with open(self.raw_paths[0], 'r') as f:
            data = f.read().split('\n')[1:-1]
            x = [[float(v) for v in r.split('\t')[1].split(',')] for r in data]
            x = torch.tensor(x, dtype=torch.float)

            y = [int(r.split('\t')[2]) for r in data]
            y = torch.tensor(y, dtype=torch.long)

        with open(self.raw_paths[1], 'r') as f:
            data = f.read().split('\n')[1:-1]
            data = [[int(v) for v in r.split('\t')] for r in data]
            edge_index = torch.tensor(data, dtype=torch.long).t().contiguous()
            edge_index, _ = coalesce(edge_index, None, x.size(0), x.size(0))
            self.is_undirected = False

        train_masks, val_masks, test_masks = [], [], []
        for f in self.raw_paths[2:]:
            tmp = np.load(f)
            train_masks += [torch.from_numpy(tmp['train_mask']).to(torch.bool)]
            val_masks += [torch.from_numpy(tmp['val_mask']).to(torch.bool)]
            test_masks += [torch.from_numpy(tmp['test_mask']).to(torch.bool)]
        train_mask = torch.stack(train_masks, dim=1)
        val_mask = torch.stack(val_masks, dim=1)
        test_mask = torch.stack(test_masks, dim=1)

        data = Data(x=x, edge_index=edge_index, y=y, train_mask=train_mask,
                    val_mask=val_mask, test_mask=test_mask)
        data = data if self.pre_transform is None else self.pre_transform(data)
        torch.save(self.collate([data]), self.processed_paths[0])

    def __repr__(self):
        return '{}()'.format(self.name)
    

class Planetoid(InMemoryDataset):
    r"""The citation network datasets :obj:`"Cora"`, :obj:`"CiteSeer"` and
    :obj:`"PubMed"` from the `"Revisiting Semi-Supervised Learning with Graph
    Embeddings" <https://arxiv.org/abs/1603.08861>`_ paper.
    Nodes represent documents and edges represent citation links.
    Training, validation and test splits are given by binary masks.

    Args:
        root (str): Root directory where the dataset should be saved.
        name (str): The name of the dataset (:obj:`"Cora"`, :obj:`"CiteSeer"`,
            :obj:`"PubMed"`).
        split (str, optional): The type of dataset split (:obj:`"public"`,
            :obj:`"full"`, :obj:`"geom-gcn"`, :obj:`"random"`).
            If set to :obj:`"public"`, the split will be the public fixed split
            from the `"Revisiting Semi-Supervised Learning with Graph
            Embeddings" <https://arxiv.org/abs/1603.08861>`_ paper.
            If set to :obj:`"full"`, all nodes except those in the validation
            and test sets will be used for training (as in the
            `"FastGCN: Fast Learning with Graph Convolutional Networks via
            Importance Sampling" <https://arxiv.org/abs/1801.10247>`_ paper).
            If set to :obj:`"geom-gcn"`, the 10 public fixed splits from the
            `"Geom-GCN: Geometric Graph Convolutional Networks"
            <https://openreview.net/forum?id=S1e2agrFvS>`_ paper are given.
            If set to :obj:`"random"`, train, validation, and test sets will be
            randomly generated, according to :obj:`num_train_per_class`,
            :obj:`num_val` and :obj:`num_test`. (default: :obj:`"public"`)
        num_train_per_class (int, optional): The number of training samples
            per class in case of :obj:`"random"` split. (default: :obj:`20`)
        num_val (int, optional): The number of validation samples in case of
            :obj:`"random"` split. (default: :obj:`500`)
        num_test (int, optional): The number of test samples in case of
            :obj:`"random"` split. (default: :obj:`1000`)
        transform (callable, optional): A function/transform that takes in an
            :obj:`torch_geometric.data.Data` object and returns a transformed
            version. The data object will be transformed before every access.
            (default: :obj:`None`)
        pre_transform (callable, optional): A function/transform that takes in
            an :obj:`torch_geometric.data.Data` object and returns a
            transformed version. The data object will be transformed before
            being saved to disk. (default: :obj:`None`)
        force_reload (bool, optional): Whether to re-process the dataset.
            (default: :obj:`False`)

    **STATS:**

    .. list-table::
        :widths: 10 10 10 10 10
        :header-rows: 1

        * - Name
          - #nodes
          - #edges
          - #features
          - #classes
        * - Cora
          - 2,708
          - 10,556
          - 1,433
          - 7
        * - CiteSeer
          - 3,327
          - 9,104
          - 3,703
          - 6
        * - PubMed
          - 19,717
          - 88,648
          - 500
          - 3
    """
    url = 'https://github.com/kimiyoung/planetoid/raw/master/data'
    geom_gcn_url = ('https://raw.githubusercontent.com/graphdml-uiuc-jlu/'
                    'geom-gcn/master')

    def __init__(
        self,
        root: str,
        name: str,
        split: str = "public",
        num_train_per_class: int = 20,
        num_val: int = 500,
        num_test: int = 1000,
        transform: Optional[Callable] = None,
        pre_transform: Optional[Callable] = None,
        force_reload: bool = False,
    ) -> None:
        self.name = name

        self.split = split.lower()
        assert self.split in ['public', 'full', 'geom-gcn', 'random']

        super().__init__(root, transform, pre_transform,
                         force_reload=force_reload)
        self.load(self.processed_paths[0])

        if split == 'full':
            data = self.get(0)
            data.train_mask.fill_(True)
            data.train_mask[data.val_mask | data.test_mask] = False
            self.data, self.slices = self.collate([data])

        elif split == 'random':
            data = self.get(0)
            data.train_mask.fill_(False)
            for c in range(self.num_classes):
                idx = (data.y == c).nonzero(as_tuple=False).view(-1)
                idx = idx[torch.randperm(idx.size(0))[:num_train_per_class]]
                data.train_mask[idx] = True

            remaining = (~data.train_mask).nonzero(as_tuple=False).view(-1)
            remaining = remaining[torch.randperm(remaining.size(0))]

            data.val_mask.fill_(False)
            data.val_mask[remaining[:num_val]] = True

            data.test_mask.fill_(False)
            data.test_mask[remaining[num_val:num_val + num_test]] = True

            self.data, self.slices = self.collate([data])

    @property
    def raw_dir(self) -> str:
        if self.split == 'geom-gcn':
            return osp.join(self.root, self.name, 'geom-gcn', 'raw')
        return osp.join(self.root, self.name, 'raw')

    @property
    def processed_dir(self) -> str:
        if self.split == 'geom-gcn':
            return osp.join(self.root, self.name, 'geom-gcn', 'processed')
        return osp.join(self.root, self.name, 'processed')

    @property
    def raw_file_names(self) -> List[str]:
        names = ['x', 'tx', 'allx', 'y', 'ty', 'ally', 'graph', 'test.index']
        return [f'ind.{self.name.lower()}.{name}' for name in names]

    @property
    def processed_file_names(self) -> str:
        return 'data.pt'

    def download(self) -> None:
        for name in self.raw_file_names:
            fs.cp(f'{self.url}/{name}', self.raw_dir)
        if self.split == 'geom-gcn':
            for i in range(10):
                url = f'{self.geom_gcn_url}/splits/{self.name.lower()}'
                fs.cp(f'{url}_split_0.6_0.2_{i}.npz', self.raw_dir)

    def process(self) -> None:
        data = read_planetoid_data(self.raw_dir, self.name)

        if self.split == 'geom-gcn':
            train_masks, val_masks, test_masks = [], [], []
            for i in range(10):
                name = f'{self.name.lower()}_split_0.6_0.2_{i}.npz'
                splits = np.load(osp.join(self.raw_dir, name))
                train_masks.append(torch.from_numpy(splits['train_mask']))
                val_masks.append(torch.from_numpy(splits['val_mask']))
                test_masks.append(torch.from_numpy(splits['test_mask']))
            data.train_mask = torch.stack(train_masks, dim=1)
            data.val_mask = torch.stack(val_masks, dim=1)
            data.test_mask = torch.stack(test_masks, dim=1)

        data = data if self.pre_transform is None else self.pre_transform(data)
        self.save([data], self.processed_paths[0])

    def __repr__(self) -> str:
        return f'{self.name}()'


class TrainDataset(Dataset):
    def __init__(self, all_triplets, train_triplets, ents, rels, num_neg=None, device='cpu') -> None:
        super().__init__()

        self.ents = ents
        self.rels = rels
        self.device = device
        self.all_triplets = all_triplets
        self.train_set = train_triplets
        self.num_ents = len(ents)
        self.num_rels = len(rels)

        self.hr2t = ddict(set)
        self.rt2h = ddict(set)
        self.h2rt = ddict(set)
        self.t2rh = ddict(set)

        self.num_neg = num_neg
        self.cross_sampling_flag = 0

        self.get_hr2t_rt2h_from_train()

    def get_hr2t_rt2h_from_train(self):
        """Get the set of hr2t and rt2h from train dataset, the data type is numpy.

        Update:
            self.hr2t_train: The set of hr2t.
            self.rt2h_train: The set of rt2h.
        """
        
        for h, t, r in self.all_triplets:
            self.hr2t[(h, r)].add(t)
            self.rt2h[(r, t)].add(h)
        for h, r in self.hr2t:
            self.hr2t[(h, r)] = np.array(list(self.hr2t[(h, r)]))
        for r, t in self.rt2h:
            self.rt2h[(r, t)] = np.array(list(self.rt2h[(r, t)]))
    
    def __getitem__(self, index):
       return self.train_set[index]
    
    def __len__(self):
        return len(self.train_set)
    
    def collate_fn(self, data):
        batch_data = {}
        neg_ent_sample = []
        self.cross_sampling_flag = 1 - self.cross_sampling_flag
        if self.cross_sampling_flag == 0:
            batch_data['mode'] = "head-batch"   # corrupt head in given true (h,r,t)
            for h, t, r in data:
                neg_head = self.head_batch(h, r, t)
                neg_ent_sample.append(neg_head)
        else:
            batch_data['mode'] = "tail-batch"   # corrupt tail in given true (h,r,t)
            for h, t, r in data:
                neg_tail = self.tail_batch(h, r, t)
                neg_ent_sample.append(neg_tail)

        batch_data["positive_sample"] = torch.LongTensor(np.array(data))
        batch_data['negative_sample'] = torch.LongTensor(np.array(neg_ent_sample))

        return batch_data
    
    def head_batch(self, h, r, t):
        neg_list = []
        neg_cur_size = 0
        while neg_cur_size < self.num_neg:
            neg_tmp = self.corrupt_head(t, r, num_max=(self.num_neg - neg_cur_size) * 2)
            neg_list.append(neg_tmp)
            neg_cur_size += len(neg_tmp)
        return np.concatenate(neg_list)[:self.num_neg]
    
    def corrupt_head(self, t, r, num_max=1):
        """Negative sampling of head entities.

        Args:
            t: Tail entity in triple.
            r: Relation in triple.
            num_max: The maximum of negative samples generated 

        Returns:
            neg: The negative sample of head entity filtering out the positive head entity.
        """
        tmp = torch.randint(low=0, high=self.num_ents, size=(num_max,)).numpy()
        mask = np.in1d(tmp, self.rt2h[(r, t)], assume_unique=True, invert=True)
        neg = tmp[mask]
        return neg
    
    def tail_batch(self, h, r, t):
        """Negative sampling of tail entities.

        Args:
            h: Head entity in triple
            t: Tail entity in triple.
            r: Relation in triple.

        Returns:
            The negative sample of tail entity. [neg_size]
        """
        neg_list = []
        neg_cur_size = 0
        while neg_cur_size < self.num_neg:
            neg_tmp = self.corrupt_tail(h, r, num_max=(self.num_neg - neg_cur_size) * 2)
            neg_list.append(neg_tmp)
            neg_cur_size += len(neg_tmp)
        return np.concatenate(neg_list)[:self.num_neg]
    
    def corrupt_tail(self, h, r, num_max=1):
        """Negative sampling of tail entities.

        Args:
            h: Head entity in triple.
            r: Relation in triple.
            num_max: The maximum of negative samples generated 

        Returns:
            neg: The negative sample of tail entity filtering out the positive tail entity.
        """
        tmp = torch.randint(low=0, high=self.num_ents, size=(num_max,)).numpy()
        mask = np.in1d(tmp, self.hr2t[(h, r)], assume_unique=True, invert=True)
        neg = tmp[mask]
        return neg


class TestDataset(Dataset):
    """Sampling triples and recording positive triples for testing.

    Attributes:
        sampler: The function of training sampler.
        hr2t_all: Record the tail corresponding to the same head and relation.
        rt2h_all: Record the head corresponding to the same tail and relation.
        num_ent: The count of entities.
    """
    def __init__(self, all_triplets, test_triplets, ents, rels, device='cpu'):
        super().__init__()

        self.ents = ents
        self.rels = rels
        self.device = device
        self.num_ent = len(ents)
        self.num_rel = len(rels)
        self.all_triplets = all_triplets
        self.test_set = test_triplets

        self.hr2t_all = ddict(set)
        self.rt2h_all = ddict(set)
        self.get_hr2t_rt2h_from_all()
    
    def __len__(self):
        return len(self.test_set)
    
    def __getitem__(self, index):
        return self.test_set[index]


    def get_hr2t_rt2h_from_all(self):
        """Get the set of hr2t and rt2h from all datasets(train, valid, and test), the data type is tensor.
        Update:
            self.hr2t_all: The set of hr2t.
            self.rt2h_all: The set of rt2h.
        """

        for h, t, r in self.all_triplets:
            self.hr2t_all[(h, r)].add(t)
            self.rt2h_all[(r, t)].add(h)
        for h, r in self.hr2t_all:
            self.hr2t_all[(h, r)] = torch.tensor(list(self.hr2t_all[(h, r)]))
        for r, t in self.rt2h_all:
            self.rt2h_all[(r, t)] = torch.tensor(list(self.rt2h_all[(r, t)]))

    def collate_fn(self, data):
        """Sampling triples and recording positive triples for testing.

        Args:
            data: The triples used to be sampled.

        Returns:
            batch_data: The data used to be evaluated.
        """
        batch_data = {}
        head_label = torch.zeros(len(data), self.num_ent)
        tail_label = torch.zeros(len(data), self.num_ent)
        for idx, triple in enumerate(data):
            head, tail, rel = triple
            head_label[idx][self.rt2h_all[(rel, tail)]] = 1.0
            tail_label[idx][self.hr2t_all[(head, rel)]] = 1.0
        batch_data["positive_sample"] = torch.from_numpy(np.array(data))
        batch_data["head_label"] = head_label
        batch_data["tail_label"] = tail_label
        
        return batch_data


class TripletDataset:
    def __init__(self, root, dataset_name, num_neg, train_ratio=0.97, test_ratio=0.03, device='cpu') -> None:
        self.root = root
        self.dataset_name = dataset_name
        self.train_ratio = train_ratio
        self.test_ratio = test_ratio
        self.num_neg = num_neg
        self.device = device

        if dataset_name in ['cornell', 'texas', 'wisconsin']:
            self.is_undirected = True
        elif dataset_name in ['chameleon', 'squirrel', 'chain', 'cora', 'citeseer', 'pubmed']:
            self.is_undirected = False
        
        self.ents, self.rels, self.triplets = self.load_data()
        self.train_set, self.test_set = self.dataset_split()
        self.num_ent = len(self.ents)
        self.num_rel = len(self.rels)
    
    def load_data(self):
        triplets = []
        
        if self.dataset_name != 'chain':
            try:
                filename = os.path.join(self.root, self.dataset_name, 'raw', 'out1_graph_edges.txt')
                with open(filename, 'r') as f:
                    for i, line in enumerate(f.readlines()):
                        if i == 0: continue
                        h, t = line.strip().split('\t')
                        triplets.append((int(h),int(t),  0))    # [h, t, r]
                    
                triplets = np.array(triplets)
                ents = np.unique(triplets[:, :2])
                rels = np.unique(triplets[:, -1:])
            except:
                filename = os.path.join(self.root, self.dataset_name, 'processed', 'data.pt')
                data = torch.load(filename)
                if len(data) == 2:
                    data = data[0]
                elif len(data) == 3:
                    data = data[-1](**data[0])
                else:
                    NotImplementedError()
                
                for line in data.edge_index.T.numpy():
                    h, t = line[0], line[1]
                    triplets.append((h, t, 0))
                
                triplets = np.array(triplets)
                ents = np.arange(np.unique(triplets[:, :2]).max() + 1)
                rels = np.unique(triplets[:, -1:])
        else:
            length = 80
            
            # add noise
            adj = (np.random.uniform(size=(length*2, length*2)) < 0.01).astype(int)
            adj = torch.from_numpy(adj)
            # adj = torch.zeros(length, length)
            
            row_idx = torch.tensor(list(range(length)))[:-1]
            col_idx = torch.tensor(list(range(length)))[1:]
            adj[row_idx, col_idx] = 1
            edge_index = adj.nonzero(as_tuple=False).t().contiguous()
            
            for ri, ci in edge_index.T.numpy().tolist():
                triplets.append((int(ri),int(ci),  0))    # [h, t, r]
            
            triplets = np.array(triplets)
            ents = np.arange(adj.shape[0])
            rels = np.unique(triplets[:, -1:])
            

        return ents, rels, triplets
    
    def dataset_split(self):
        
        if self.dataset_name != 'chain':
            num_trips = self.triplets.shape[0]
            selector = np.arange(num_trips)
            np.random.shuffle(selector)
            triplets = self.triplets[selector]
            num_train = int(num_trips * self.train_ratio)

            train_set = triplets[:num_train]
            test_set = triplets[num_train:]

            if self.is_undirected:
                triplets_inv = np.concatenate([triplets.copy()[:, :2][:, ::-1], triplets[:, -1:] + 1], axis=-1)
                triplets = np.concatenate([triplets, triplets_inv], axis=0)
                train_set_inv = np.concatenate([train_set.copy()[:, :2][:, ::-1], train_set[:, -1:] + 1], axis=-1)
                train_set = np.concatenate([train_set, train_set_inv], axis=0)
                test_set_inv = np.concatenate([test_set.copy()[:, :2][:, ::-1], test_set[:, -1:] + 1], axis=-1)
                test_set = np.concatenate([test_set, test_set_inv], axis=0)

                self.triplets = triplets
                self.ents = np.unique(triplets[:, :2])
                self.rels = np.unique(triplets[:, -1:])
            
            return TrainDataset(triplets, train_set, self.ents, self.rels, self.num_neg, device=self.device), \
                TestDataset(triplets, test_set, self.ents, self.rels, device=self.device)
                
        else:
            return TrainDataset(self.triplets, self.triplets, self.ents, self.rels, self.num_neg, device=self.device), \
                TestDataset(self.triplets, self.triplets, self.ents, self.rels, device=self.device)


class ChainDataset:
    def __init__(self, normalization, num_chains, chain_len, num_neg, 
                 num_class=2, noise=0.00, noise_type=None, need_orig=False,
                 train_ratio=0.9, test_ratio=0.1, device='cpu') -> None:
        self.normalization = normalization
        self.num_chains = num_chains
        self.chain_len = chain_len
        self.num_class = num_class
        self.noise = noise
        self.noise_type = noise_type
        self.need_orig = need_orig

        self.num_neg = num_neg
        self.train_ratio = train_ratio
        self.test_ratio = test_ratio
        self.device = device

        self.ents, self.rels, self.triplets, self.is_undirected = self.load_data()
        self.train_set, self.test_set = self.dataset_split()
        self.num_ent = len(self.ents)
        self.num_rel = len(self.rels)


    def load_data(self):
        
        raw_adj, norm_adj, features, labels, idx_train, idx_val, idx_test, is_undirected = load_citation_syn_chain_IDM(
                                                                                                normalization=self.normalization, 
                                                                                                cuda=False, 
                                                                                                num_chains=self.num_chains, 
                                                                                                chain_len=self.chain_len,
                                                                                                num_class=self.num_class,
                                                                                                noise=self.noise,
                                                                                                noise_type=self.noise_type,
                                                                                                need_orig=self.need_orig)
        
        raw_adj = raw_adj.to_dense()
        heads, tails = torch.where(raw_adj == 1)
        rels = torch.zeros_like(heads)

        triplets = torch.stack([heads, tails, rels], dim=-1)    # [h,t,r]
        ents = triplets[:, :2].unique()
        rels = triplets[:, 2:].unique()

        return ents.numpy(), rels.numpy(), triplets.numpy(), is_undirected
    
    def dataset_split(self):
        num_trips = self.triplets.shape[0]
        selector = np.arange(num_trips)
        np.random.shuffle(selector)
        triplets = self.triplets[selector]
        num_train = int(num_trips * self.train_ratio)

        train_set = triplets[:num_train]
        test_set = triplets[num_train:]

        return TrainDataset(triplets, triplets, self.ents, self.rels, self.num_neg, device=self.device), \
               TestDataset(triplets, test_set, self.ents, self.rels, device=self.device)

        


def get_heterophilic_dataset_IDM(dataset_name, data_path, idx_split, device='cuda'):
    dataset_name = dataset_name.lower()
    assert dataset_name in ['cornell', 'texas', 'wisconsin', 'chameleon', 'squirrel', 'film']
    if dataset_name in ['cornell', 'texas', 'wisconsin', 'film']:
        dataset = WebKB_new(data_path, dataset_name, transform=T.NormalizeFeatures())
    elif dataset_name in ['chameleon', 'squirrel']:
        dataset = WikipediaNetwork(data_path, dataset_name, transform=T.NormalizeFeatures())
    elif dataset_name in ['cora', 'citeseer', 'pubmed']:
        dataset = Planetoid(data_path, dataset_name, transform=T.NormalizeFeatures())
    data = dataset[0]
    train_mask, val_mask, test_mask = data.train_mask[:, idx_split], data.val_mask[:, idx_split], \
                                      data.test_mask[:, idx_split]
    edge_index, x, y = data.edge_index, data.x, data.y
    y = y.long()
    row, col = edge_index[0, :], edge_index[1, :]
    val = np.ones(len(row))
    raw_adj = sp.coo_matrix((val, (row,col)), shape=(x.size(0), x.size(0)))
    sp_adj = aug_normalized_adjacency(raw_adj)
    sp_adj = sparse_mx_to_torch_sparse_tensor(sp_adj, device=device)
    raw_adj = sparse_mx_to_torch_sparse_tensor(raw_adj, device=device)
    return raw_adj, sp_adj, x, y, train_mask, val_mask, test_mask, dataset.is_undirected


if __name__ == "__main__":
    # raw_adj, sp_adj, features, labels, idx_train, idx_val, idx_test = get_heterophilic_dataset_IDM('chameleon', './dataset', 0)
    # TripletDataset('/home/test/lrz/ContrastivePE/dataset', 'chameleon')
    ChainDataset('AugNormAdj', 3, 10, 10)
    print()