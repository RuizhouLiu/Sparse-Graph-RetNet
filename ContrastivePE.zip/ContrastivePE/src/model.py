import torch
import torch.nn as nn
import torch.nn.functional as F

from .eval import calc_ranks

def get_theta(dim):
    return 1.0 / (10000 ** (torch.arange(0, dim) / dim))


class PEModel(nn.Module):
    def __init__(self, nent, nrel, rank, x_rank, phi_rank, init_size=0.001, reg_weight=0.0, margin=6.0, epsilon=2.0) -> None:
        super().__init__()
        
        self.nent = nent
        self.nrel = nrel
        self.rank = rank
        self.margin = margin
        self.epsilon = epsilon
        self.x_rank = x_rank
        self.phi_rank = phi_rank
        self.reg_weight = reg_weight

        self.theta = nn.Parameter(get_theta(rank).unsqueeze(0), requires_grad=False)

        self.ent_x = nn.Parameter(init_size * torch.randn((nent, x_rank)))
        self.ent_phi = nn.Parameter(init_size * torch.zeros(nent, phi_rank))

        self.rel_x = nn.Parameter(init_size * torch.randn((nrel, x_rank)))
        self.rel_phi = nn.Parameter(init_size * torch.zeros((nrel, phi_rank)))

        self.margin = nn.Parameter(
            torch.Tensor([self.margin]), 
            requires_grad=False
        )
        self.embedding_range = nn.Parameter(
            torch.Tensor([(self.margin.item() + self.epsilon) / rank]), 
            requires_grad=False
        )

        # params init
        nn.init.uniform_(tensor=self.ent_x.data, a=-self.embedding_range.item(), b=self.embedding_range.item())
        nn.init.uniform_(tensor=self.ent_phi.data, a=-self.embedding_range.item(), b=self.embedding_range.item())
        nn.init.uniform_(tensor=self.rel_x.data, a=-self.embedding_range.item(), b=self.embedding_range.item())
        nn.init.uniform_(tensor=self.rel_phi.data, a=-self.embedding_range.item(), b=self.embedding_range.item())
    
    def forward(self, batch_data):
        """
        triplets: [h,t,r]
        """
        mode = batch_data['mode']
        pos_triplets = batch_data['positive_sample']
        neg_samples = batch_data['negative_sample']

        if mode == 'head-batch':
            h = pos_triplets[:, 0]
            t = pos_triplets[:, 1]
            r = pos_triplets[:, 2]

            # h_x, h_phi = self.ent_x[h], self.ent_phi[h]
            h_x, h_phi = self.ent_x[h], self.get_ent_phi(h)
            t_x, t_phi = self.ent_x[t], self.get_ent_phi(t)
            r_x, r_phi = self.rel_x[r], self.rel_phi[r]
            neg_h_x, neg_h_phi = self.ent_x[neg_samples], self.get_ent_phi(neg_samples)

            pos_scores = (self.theta * (t_x - r_x) + (t_phi - r_phi)) - (self.theta * h_x + h_phi)
            neg_scores = (self.theta * (t_x - r_x) + (t_phi - r_phi)).unsqueeze(1) - (self.theta.unsqueeze(1) * neg_h_x + neg_h_phi)
        
        elif mode == 'tail-batch':
            h = pos_triplets[:, 0]
            t = pos_triplets[:, 1]
            r = pos_triplets[:, 2]

            h_x, h_phi = self.ent_x[h], self.get_ent_phi(h)
            t_x, t_phi = self.ent_x[t], self.get_ent_phi(t)
            r_x, r_phi = self.rel_x[r], self.rel_phi[r]

            neg_t_x, neg_t_phi = self.ent_x[neg_samples], self.get_ent_phi(neg_samples)

            pos_scores = (self.theta * (h_x + r_x) + (h_phi + r_phi)) - (self.theta * t_x + t_phi)
            neg_scores = (self.theta * (h_x + r_x) + (h_phi + r_phi)).unsqueeze(1) - (self.theta.unsqueeze(1) * neg_t_x + neg_t_phi)
        
        pos_scores = self.margin.item() - torch.norm(pos_scores, p=1, dim=-1)
        neg_scores = self.margin.item() - torch.norm(neg_scores, p=1, dim=-1)

        loss = self.loss_func(pos_scores, neg_scores)
        loss += self.regularization()

        return loss
    
    def get_ent_phi(self, e):
        # return (self.theta / torch.pi) * F.tanh(self.ent_phi[e])
        return self.ent_phi[e]

        
    def loss_func(self, pos_scores, neg_scores):
        neg_scores = F.logsigmoid(-neg_scores).mean(dim = 1)
        pos_scores = F.logsigmoid(pos_scores)

        positive_sample_loss = - pos_scores.mean()
        negative_sample_loss = - neg_scores.mean()

        loss = (positive_sample_loss + negative_sample_loss) / 2

        return loss
    
    def regularization(self):
        regularization = self.reg_weight * (
            self.ent_x.norm(p = 3)**3 + self.rel_x.norm(p = 3)**3
        )

        regularization += self.reg_weight * (
            self.ent_phi.norm(p = 3)**3 + self.rel_phi.norm(p = 3)**3
        )

        return regularization
    
    @torch.no_grad()
    def test_one_step(self, batch_data):
        """Getting samples and validation in KG model.
        
        Args:
            batch: The evalutaion data.
            batch_idx: The dict_key in batch, type: list.

        Returns:
            results: mrr and hits@1,3,10.
        """
        
        head_label = batch_data["head_label"]
        tail_label = batch_data["tail_label"]
        pos_triplets = batch_data['positive_sample']
        h, t, r = pos_triplets[:, 0], pos_triplets[:, 1], pos_triplets[:, 2]

        h_x, h_phi = self.ent_x[h], self.ent_phi[h]
        t_x, t_phi = self.ent_x[t], self.ent_phi[t]
        r_x, r_phi = self.rel_x[r], self.rel_phi[r]
        ent_x, ent_phi = self.ent_x.unsqueeze(0), self.ent_phi.unsqueeze(0)

        # head label
        head_scores = (self.theta * (t_x - r_x) + (t_phi - r_phi)).unsqueeze(1) - (self.theta.unsqueeze(1) * ent_x + ent_phi)
        head_scores = self.margin.item() - torch.norm(head_scores, p=1, dim=-1)
        head_idx = pos_triplets[:, 0]
        head_ranks = calc_ranks(head_idx, head_label, head_scores)
        
        # tail label
        tail_scores = (self.theta * (h_x + r_x) + (h_phi + r_phi)).unsqueeze(1) - (self.theta.unsqueeze(1) * ent_x + ent_phi)
        tail_scores = self.margin.item() - torch.norm(tail_scores, p=1, dim=-1)
        tail_idx = pos_triplets[:, 1]
        tail_ranks = calc_ranks(tail_idx, tail_label, tail_scores)

        ranks = torch.cat([tail_ranks, head_ranks])

        return ranks.cpu().tolist()
    
        


class Undirected_SimplePE(nn.Module):
    def __init__(self, nent, rank, init_size=0.001, reg_weight=0.0) -> None:
        super().__init__()

        self.nent = nent
        self.rank = rank
        self.reg_weight = reg_weight

        self.ents = nn.Parameter(init_size * torch.randn(nent, rank))
    
    def forward(self, batch_data):
        """
        triplets: [h,t,r]
        """

        mode = batch_data['mode']
        pos_triplets = batch_data['positive_sample']
        neg_samples = batch_data['negative_sample']

        if mode == 'head-batch':
            h = pos_triplets[:, 0]
            t = pos_triplets[:, 1]

            h = self.ents[h]
            t = self.ents[t]
            neg_h = self.ents[neg_samples]

            pos_scores = F.cosine_similarity(h, t, dim=-1)
            neg_scores = F.cosine_similarity(neg_h, t.unsqueeze(1), dim=-1)

        elif mode == 'tail-batch':
            h = pos_triplets[:, 0]
            t = pos_triplets[:, 1]

            h = self.ents[h]
            t = self.ents[t]
            neg_t = self.ents[neg_samples]

            pos_scores = F.cosine_similarity(h, t, dim=-1)
            neg_scores = F.cosine_similarity(h.unsqueeze(1), neg_t, dim=-1)
        
        loss = self.loss_func(pos_scores, neg_scores)
        loss += self.regularization()

        return loss


    def loss_func(self, pos_scores, neg_scores):
        neg_scores = F.logsigmoid(-neg_scores).mean(dim = 1)
        pos_scores = F.logsigmoid(pos_scores)

        positive_sample_loss = - pos_scores.mean()
        negative_sample_loss = - neg_scores.mean()

        loss = (positive_sample_loss + negative_sample_loss) / 2

        return loss
    
    def regularization(self):
        regularization = self.reg_weight * (
            self.ents.norm(p = 3)**3
        )

        return regularization
    
    @torch.no_grad()
    def test_one_step(self, batch_data):
        """Getting samples and validation in KG model.
        
        Args:
            batch: The evalutaion data.
            batch_idx: The dict_key in batch, type: list.

        Returns:
            results: mrr and hits@1,3,10.
        """
        head_label = batch_data["head_label"]
        tail_label = batch_data["tail_label"]
        pos_triplets = batch_data['positive_sample']
        h, t = pos_triplets[:, 0], pos_triplets[:, 1]

        h = self.ents[h]
        t = self.ents[t]
        ent = self.ents

        head_scores = F.cosine_similarity(ent.unsqueeze(0), t.unsqueeze(1), dim=-1)
        head_idx = pos_triplets[:, 0]
        head_ranks = calc_ranks(head_idx, head_label, head_scores)

        tail_scores = F.cosine_similarity(ent.unsqueeze(0), h.unsqueeze(1), dim=-1)
        tail_idx = pos_triplets[:, 1]
        tail_ranks = calc_ranks(tail_idx, tail_label, tail_scores)

        ranks = torch.cat([tail_ranks, head_ranks])
        return ranks.cpu().tolist()


class UndirectedPE(nn.Module):
    def __init__(self, nent, nrel, rank, init_size=0.001, reg_weight=0.0) -> None:
        super().__init__()

        self.nent = nent
        self.nrel = nrel
        self.rank = rank
        self.reg_weight = reg_weight

        self.ents = nn.Parameter(init_size * torch.randn(nent, rank, 1))
        self.rels = nn.Parameter(init_size * torch.randn(nrel, rank, rank))
    
    def forward(self, batch_data):
        """
        triplets: [h,t,r]
        """

        mode = batch_data['mode']
        pos_triplets = batch_data['positive_sample']
        neg_samples = batch_data['negative_sample']

        if mode == 'head-batch':
            h = pos_triplets[:, 0]
            t = pos_triplets[:, 1]
            r = pos_triplets[:, 2]

            h = self.get_ents(h)
            t = self.get_ents(t)
            r = self.rels[r]
            neg_h = self.get_ents(neg_samples)

            pos_scores = h.transpose(1,2) @ r @ t
            neg_scores = neg_h.transpose(2,3) @ r.unsqueeze(1) @ t.unsqueeze(1)
        
        elif mode == 'tail-batch':
            h = pos_triplets[:, 0]
            t = pos_triplets[:, 1]
            r = pos_triplets[:, 2]

            h = self.get_ents(h)
            t = self.get_ents(t)
            r = self.rels[r]
            neg_t = self.get_ents(neg_samples)

            pos_scores = h.transpose(1,2) @ r @ t
            neg_scores = h.transpose(1,2).unsqueeze(1) @ r.unsqueeze(1) @ neg_t
        
        loss = self.loss_func(pos_scores, neg_scores)
        loss += self.regularization()

        return loss
    
    def get_ents(self, e=None):
        if e is None:
            ents = self.ents
        else:
            ents = self.ents[e]
        return ents / ents.detach().norm(dim=-2, keepdim=True)
    

    def loss_func(self, pos_scores, neg_scores):
        neg_scores = F.logsigmoid(-neg_scores).mean(dim = 1)
        pos_scores = F.logsigmoid(pos_scores)

        positive_sample_loss = - pos_scores.mean()
        negative_sample_loss = - neg_scores.mean()

        loss = (positive_sample_loss + negative_sample_loss) / 2

        return loss
    
    def regularization(self):
        regularization = self.reg_weight * (
            self.ents.norm(p = 3)**3
        )

        return regularization

    @torch.no_grad()
    def test_one_step(self, batch_data):
        """Getting samples and validation in KG model.
        
        Args:
            batch: The evalutaion data.
            batch_idx: The dict_key in batch, type: list.

        Returns:
            results: mrr and hits@1,3,10.
        """
        head_label = batch_data["head_label"]
        tail_label = batch_data["tail_label"]
        pos_triplets = batch_data['positive_sample']
        h, t, r = pos_triplets[:, 0], pos_triplets[:, 1], pos_triplets[:, 2]

        h = self.get_ents(h)
        t = self.get_ents(t)
        r = self.rels[r]
        ents = self.get_ents()

        head_scores = (ents.unsqueeze(0).transpose(2,3) @ r.unsqueeze(1) @ t.unsqueeze(1)).squeeze()
        head_idx = pos_triplets[:, 0]
        head_ranks = calc_ranks(head_idx, head_label, head_scores)

        tail_scores = (h.unsqueeze(1).transpose(2,3) @ r.unsqueeze(1) @ ents.unsqueeze(0)).squeeze()
        tail_idx = pos_triplets[:, 1]
        tail_ranks = calc_ranks(tail_idx, tail_label, tail_scores)

        ranks = torch.cat([tail_ranks, head_ranks])
        return ranks.cpu().tolist()