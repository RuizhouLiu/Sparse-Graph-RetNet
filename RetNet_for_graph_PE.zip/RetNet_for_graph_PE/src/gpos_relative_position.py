import torch
import torch.nn as nn

class GPOS(nn.Module):
    def __init__(self, head_dim, scale_base=512, args=None) -> None:
        super().__init__()

        self.head_dim = head_dim
        self.scale_base = scale_base

        self.theta, self.ent_x, self.ent_phi, self.sin, self.cos = self.load_sinusoid_inp(args.sinusoid_inp_file)
        
        self.theta = nn.Parameter(self.theta, requires_grad=False)
        self.ent_x = nn.Parameter(self.ent_x, requires_grad=False)
        self.ent_phi = nn.Parameter(self.ent_phi, requires_grad=False)

        self.sin = nn.Parameter(self.sin, requires_grad=False)
        self.cos = nn.Parameter(self.cos, requires_grad=False)

        self.register_buffer(
            "scale", (torch.arange(0, head_dim, 2) + 0.4 * head_dim) / (1.4 * head_dim)
        )

        # self.get_decay_mat()
    

    def load_sinusoid_inp(self, filepath):
        model_params = torch.load(filepath, map_location='cpu')
        ent_x = model_params['ent_x']
        ent_phi = model_params['ent_phi']
        theta = model_params['theta']
        sin, cos = torch.sin(theta * ent_x + ent_phi), torch.cos(theta * ent_x + ent_phi)

        return theta, ent_x, ent_phi, sin, cos
    
    def forward(self, x):
        sin = self.duplicate_interleave(self.sin)
        cos = self.duplicate_interleave(self.cos)

        return (x * cos[:, :x.shape[-1]]) + (self.rotate_every_two(x) * sin)[:, :, :x.shape[-1]]
        
    
    def duplicate_interleave(self, m):
        """
        A simple version of `torch.repeat_interleave` for duplicating a matrix while interleaving the copy.
        input:  [n, d]
        output: [n, 2d]
        dim=-1, [1,2,3,4] -> [1,1,2,2,3,3,4,4]
        """
        dim0 = m.shape[0]
        m = m.view(-1, 1)  # flatten the matrix
        m = m.repeat(1, 2)  # repeat all elements into the 2nd dimension
        m = m.view(dim0, -1)  # reshape into a matrix, interleaving the copy
        return m
    
    def rotate_every_two(self, x):
        """
        rotate two elements in last dim
        input:  [b, n, d]
        output: [b, n, d]
        dim=-1, [1,2,3,4] -> [2,-1,4,-3]
        """
        x1 = x[:, :, ::2]
        x2 = x[:, :, 1::2]
        x = torch.stack((-x2, x1), dim=-1)
        if x.shape[-1]%2 == 1:
            # fill last dim with zero if hidden_size is odd
            x2 = torch.concat((x2, torch.zeros_like(x2[:, :, :1])), dim=-1)
        return x.flatten(-2)  # in einsum notation: rearrange(x, '... d j -> ... (d j)')\
    
    # def get_decay_mat(self):

    #     # scale = self.scale ** torch.arange(min_pos, max_pos, 1).to(self.scale).div(self.scale_base)[:, None]
    #     pos = self.theta * self.ent_x + self.ent_phi

    #     dist_mat = (pos.unsqueeze(1) - pos.unsqueeze(0)).norm(dim=-1)
    #     self.scale ** dist_mat

    #     print()


class Undirected_SimpleGPOS(nn.Module):
    def __init__(self, args) -> None:
        super().__init__()

        self.ents = torch.load(args.sinusoid_inp_file, map_location='cpu')['ents'].squeeze()
        self.ents = nn.Parameter(self.ents.unsqueeze(0), requires_grad=False)
    
    def forward(self, x):
        return x * (self.ents / self.ents.norm(dim=-1, keepdim=True))
        # return x * self.ents


class LearnGPOS(nn.Module):
    def __init__(self, head_size, seq_len, init_size=0.001) -> None:
        super().__init__()

        self.head_size = head_size
        self.seq_len = seq_len
        self.ape = nn.Parameter(init_size * torch.randn(seq_len, head_size))
    
    def forward(self, x):
        return x + self.ape