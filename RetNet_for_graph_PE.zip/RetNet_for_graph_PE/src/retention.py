import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .xpos_relative_position import XPOS
from .gpos_relative_position import GPOS, Undirected_SimpleGPOS, LearnGPOS



class GraphConvolution(nn.Module):                            
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(1, in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(1, 1, out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):             # 这里代码做了简化如 3.2节。
        support = input @ self.weight   # (2708, 16) = (2708, 1433) X (1433, 16)
        # output = torch.spmm(adj, support)      # (2708, 16) = (2708, 2708) X (2708, 16)
        output = adj.to_dense() @ support
        if self.bias is not None:
            return output + self.bias          # 加上偏置 (2708, 16)
        else:
            return output                      # (2708, 16)
    
    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class GCN(nn.Module):                                             # 定义两层GCN
    def __init__(self, in_dim, hid_dim, out_dim, dropout=0.5, args=None):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(in_dim, hid_dim)
        self.gc2 = GraphConvolution(hid_dim, out_dim)
        self.dropout = dropout

    def forward(self, x, adj):
        x = torch.nn.functional.relu(self.gc1(x, adj))
        x = torch.nn.functional.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return x



class SimpleRetention(nn.Module):
    def __init__(self, PE, hidden_size, seq_len, head_size=None, double_v_dim=False, args=None, size=0.0001) -> None:
        super().__init__()

        self.hidden_size = hidden_size
        if head_size is None:
            head_size = hidden_size
        self.head_size = head_size

        self.v_dim = head_size * 2 if double_v_dim else head_size

        self.W_Q = nn.Parameter(size * torch.randn(hidden_size, head_size) / hidden_size)
        self.W_K = nn.Parameter(size * torch.randn(hidden_size, head_size) / hidden_size)
        self.W_V = nn.Parameter(size * torch.randn(hidden_size, self.v_dim) / hidden_size)
        self.W_P = nn.Parameter(size * torch.randn(head_size, head_size) / hidden_size)

        self.eye = nn.Parameter(torch.Tensor(torch.eye(seq_len).unsqueeze(0)), requires_grad=False)

        self.PE = nn.Parameter(PE.unsqueeze(0), requires_grad=False)
    
        self.xpos = XPOS(head_size)
        if args.is_undirected:
            # self.gpos = Undirected_SimpleGPOS(args)
            self.gpos = GPOS(head_size, args=args)
            self.add_gpos = LearnGPOS(hidden_size, seq_len)
        else:
            self.gpos = GPOS(head_size, args=args)
        self.gcn = GCN(hidden_size, hidden_size * 2, head_size * 2)
        
    
    def forward(self, X, raw_adj, sp_adj, rand_sign):
        """
        X: (batch_size, sequence_length, hidden_size)
        """
        # import ipdb; ipdb.set_trace()
        PE =  (self.PE * rand_sign) @ self.W_P
        D = torch.linalg.inv(self.eye - raw_adj)
        # D = D / (D.detach().sum(dim=-1, keepdim=True) + 1e-7) # second normalizing trick

        # X = self.add_gpos(X)

        Q = (X @ self.W_Q) 
        K = (X @ self.W_K)

        # Q = self.xpos(Q)
        # K = self.xpos(K, downscale=True)

        Q = self.gpos(Q) + PE
        K = self.gpos(K) + PE

        # Q = Q
        # K = K

        # spatial_pos = self.gcn(X, sp_adj)
        # pos_Q, pos_K = torch.chunk(spatial_pos, 2, dim=-1)

        # Q = Q + pos_Q 
        # K = K + pos_K

        V = X @ self.W_V

        ret = (Q @ K.permute(0, 2, 1) / (self.hidden_size ** 0.5)) * D  # first normalizing trick
        # invariant after normalization
        ret = ret / ret.detach().abs().sum(dim=-1, keepdim=True).clamp(min=1, max=5e4) # third normalizing trick
        return  ret @ V



class MultiScaleRetention(nn.Module):
    def __init__(self, PE, hidden_size, heads, seq_len, double_v_dim=False, args=None, size=0.0001) -> None:
        super().__init__()

        self.hidden_size = hidden_size
        self.v_dim = hidden_size * 2 if double_v_dim else hidden_size
        self.heads = heads
        assert hidden_size % heads == 0, "hidden_size must be divisible by heads"
        self.head_size = hidden_size // heads
        self.head_v_dim = hidden_size * 2 if double_v_dim else hidden_size

        # self.gammas = (1 - torch.exp(torch.linspace(math.log(1/32), math.log(1/512), heads))).detach().cpu().tolist()
        self.scales = nn.Parameter(torch.linspace(0.1, 1, heads), requires_grad=False)
        self.gammas = nn.Parameter(torch.Tensor(torch.ones(heads)))

        self.swish = lambda x: x * torch.sigmoid(x)
        self.W_G = nn.Parameter(size * torch.randn(hidden_size, self.v_dim) / hidden_size)
        self.W_O = nn.Parameter(size * torch.randn(self.v_dim, hidden_size) / hidden_size)
        self.group_norm = nn.GroupNorm(heads, self.v_dim)

        self.retentions = nn.ModuleList([
            SimpleRetention(PE, self.hidden_size, seq_len, self.head_size, double_v_dim, args=args)
            for _ in range(heads)
        ])

    def forward(self, X, raw_adj, sp_adj, sign):
        Y = []
        gammas = torch.exp(-self.scales * F.softplus(self.gammas))
        for i in range(self.heads):
            Y.append(self.retentions[i](X, raw_adj * gammas[i], sp_adj, sign))

        Y = torch.cat(Y, dim=2)
        Y_shape = Y.shape
        Y = self.group_norm(Y.reshape(-1, self.v_dim)).reshape(Y_shape)

        return (self.swish(X @ self.W_G) * Y) @ self.W_O
    