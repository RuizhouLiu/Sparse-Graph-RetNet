import torch
import torch.nn as nn
import torch.nn.functional as F

from retention import MultiScaleRetention


class RetNet(nn.Module):
    def __init__(self, layers, hidden_dim, ffn_size, heads, seq_len, double_v_dim=False, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

        self.layers = layers
        self.layer_norms_1 = nn.ModuleList([
            nn.LayerNorm(hidden_dim) for _ in range(layers)
        ])

        self.retentions = nn.ModuleList([
            MultiScaleRetention(hidden_dim, heads, seq_len, double_v_dim)
            for _ in range(layers)
        ])

        self.ffns = nn.ModuleList([
            nn.Sequential(
                nn.Linear(hidden_dim, ffn_size),
                nn.GELU(),
                nn.Linear(ffn_size, hidden_dim)
            )
            for _ in range(layers)
        ])

        self.layer_norms_2 = nn.ModuleList([
            nn.LayerNorm(hidden_dim)
            for _ in range(layers)
        ])
    
    def forward(self, X, raw_adj, sp_adj):
        for i in range(self.layers):
            Y = self.retentions[i](self.layer_norms_1[i](X), raw_adj, sp_adj) + X
            
            X = self.ffns[i](self.layer_norms_2[i](Y)) + Y

        return X


class RetGraph(nn.Module):
    def __init__(self, layers, hidden_dim, ffn_size, heads, double_v_dim, 
                 num_nodes, num_class, input_feats=None,
                 *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

        if input_feats == None:
            self.node_embs = nn.Parameter(torch.randn(num_nodes, hidden_dim))
        else:
            self.node_embs = nn.Parameter(input_feats, requires_grad=False)
        self.embs_proj = nn.Linear(self.node_embs.shape[-1], hidden_dim)
        self.retnet = RetNet(layers, hidden_dim, ffn_size, heads, num_nodes, double_v_dim)
        self.gelu = nn.GELU()
        self.out_layer = nn.Sequential(
                nn.Linear(hidden_dim, ffn_size),
                nn.GELU(),
                nn.Linear(ffn_size, num_class)
            )

        self.params_init()
    
    def params_init(self):
        torch.nn.init.normal_(self.embs_proj.weight)
        torch.nn.init.zeros_(self.embs_proj.bias)

        for name, param in self.out_layer.named_parameters():
            if str.endswith(name, 'weight'):
                torch.nn.init.normal_(param)
            elif str.endswith(name, 'bias'):
                torch.nn.init.zeros_(param)
    
    def forward(self, node_ids, raw_adj, sp_adj):
        X = self.node_embs[node_ids]
        X = self.gelu(self.embs_proj(X))
        out = self.retnet(X, raw_adj, sp_adj)

        out = self.out_layer(out)
        return out

        
