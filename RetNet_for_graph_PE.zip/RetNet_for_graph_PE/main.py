import os
import sys
import yaml
import argparse
import torch
import shutil
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from tqdm import tqdm
import logging
import random
from torch.utils.tensorboard import SummaryWriter

from src.utils import Config, accuracy, get_dir, position_encoding, f1_score
from src.datasets_utils import get_heterophilic_dataset_IDM, load_citation_syn_chain_IDM
from src.retnet import RetGraph


def train_one_step(epoch_i: int, 
                   input_data: torch.Tensor, labels:torch.Tensor, 
                   raw_adj: torch.Tensor, sp_adj: torch.Tensor,
                   idx_train: torch.Tensor, idx_val: torch.Tensor, idx_test: torch.Tensor,
                   model: nn.Module, optimizer: torch.optim.Optimizer,
                   writer: SummaryWriter):
    # forward process and get loss
    model.train()
    out_feats = model(input_data.unsqueeze(0), raw_adj.unsqueeze(0), sp_adj.unsqueeze(0)).squeeze()
    out_feats = F.log_softmax(out_feats, dim=1)
    loss_train = F.nll_loss(out_feats[idx_train], labels[idx_train])
    acc_train = accuracy(out_feats[idx_train], labels[idx_train])
    
    # backward process and update params
    optimizer.zero_grad()
    loss_train.backward()
    optimizer.step()

    # get performance
    loss_val = F.nll_loss(out_feats[idx_val], labels[idx_val])
    acc_val = accuracy(out_feats[idx_val], labels[idx_val])
    loss_test = F.nll_loss(out_feats[idx_test], labels[idx_test])
    acc_test = accuracy(out_feats[idx_test], labels[idx_test])
    f1_test = f1_score(out_feats[idx_test], labels[idx_test])

    writer.add_scalar('loss_train', loss_train, epoch_i)
    writer.add_scalar('loss_val', loss_val, epoch_i)
    writer.add_scalar('loss_test', loss_test, epoch_i)
    writer.add_scalar('acc_train', acc_train, epoch_i)
    writer.add_scalar('acc_val', acc_val, epoch_i)
    writer.add_scalar('acc_test', acc_test, epoch_i)

    logging.info(f"Epoch {epoch_i}\tloss_train:{loss_train.item():.4f} | acc_train: {acc_train:.4f} | acc_val: {acc_val:.4f} | acc_test: {acc_test:.4f} | f1_test: {f1_test:.4f}")

    return loss_val.item(), acc_val.item(), loss_test.item(), acc_test.item()

@torch.no_grad()
def test(input_data: torch.Tensor, labels:torch.Tensor, raw_adj:torch.Tensor, sp_adj:torch.Tensor,
         idx_test: torch.Tensor, model: nn.Module):
    model.eval()
    out_feats = model(input_data.unsqueeze(0), raw_adj.unsqueeze(0), sp_adj.unsqueeze(0)).squeeze()
    out_feats = F.log_softmax(out_feats, dim=1)
    loss_test = F.nll_loss(out_feats[idx_test], labels[idx_test])
    acc_test = accuracy(out_feats[idx_test], labels[idx_test])

    outstr = "Test set results:" + \
             " loss= {:.4f}".format(loss_test.item()) + \
             " accuracy= {:.4f}".format(acc_test.item())
    logging.info(outstr)


args_parser = argparse.ArgumentParser(description="RetNet for Graphs")
args_parser.add_argument(
    "--config_path", default=None
)
input_arg = args_parser.parse_args()


def main():

    if input_arg.config_path is None:
        config_file = "./config/cornell_config.yaml"
    else:
        config_file = input_arg.config_path
    args = Config(config_file).get()

    log_dir, save_dir = get_dir(os.path.join(args.log_dir, args.dataset_name), os.path.join(args.save_dir, args.dataset_name))
    writer = SummaryWriter(log_dir=log_dir, comment=args.dataset_name)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir, exist_ok=True)
    # prepareing logger
    logging.basicConfig(
        format="%(asctime)s %(levelname)-8s %(message)s",
        level=logging.INFO,
        datefmt="%Y-%m-%d %H:%M:%S",
        filename=os.path.join(save_dir, "train.log")
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s %(levelname)-8s %(message)s")
    console.setFormatter(formatter)
    logging.getLogger("").addHandler(console)
    logging.info("Saving logs in: {}".format(save_dir))
    logging.info(f"dataset is {args.dataset_name}")
    # prepareing logger

    # copying code and configs
    folder_path = os.path.split(os.path.abspath(__file__))[0]
    shutil.copytree(os.path.join(folder_path, "src"), os.path.join(save_dir, "code", "src"))
    shutil.copytree(os.path.join(folder_path, "config"), os.path.join(save_dir, "code", "config"))


    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.device != 'cpu':
        torch.cuda.manual_seed(args.seed)
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    torch.backends.cudnn.enabled = True
    
    device = f'cuda:{args.device}' if torch.cuda.is_available() and args.device != 'cpu' else 'cpu'

    # load data
    if args.dataset_name == 'chain':
        raw_adj, norm_adj, features, labels, idx_train, idx_val, idx_test, is_undirected = load_citation_syn_chain_IDM(args.normalization, False, args.num_chains, args.chain_len, 
                                                                                                                       noise=args.noise, noise_type=args.noise_type)
    else:
        raw_adj, norm_adj, features, labels, idx_train, idx_val, idx_test, is_undirected = get_heterophilic_dataset_IDM(args.dataset_name, args.data_path, args.idx_split, device='cpu')
    args.is_undirected = is_undirected

    PE = position_encoding(norm_adj.cpu(), k=args.hidden_dim // args.heads, is_undirected=is_undirected)

    model = RetGraph(args.layers, args.hidden_dim, args.ffn_size, args.heads, args.double_v_dim, 
                     num_nodes=raw_adj.shape[0], num_class=len(labels.unique()), PE=PE,
                     input_feats=features, args=args)
    if eval(args.ckpt) is not None:
        model = model.load_state_dict(torch.load(args.ckpt)).to(device)

    # setup optimizer
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, betas=[args.beta1, args.beta2], weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min')

    # laod to cuda
    model       = model.to(device)
    raw_adj     = raw_adj.to(device)
    norm_adj      = norm_adj.to(device).to_dense()
    labels      = labels.to(device).to_dense()
    idx_train   = idx_train.to(device)#[:10]
    idx_val     = idx_val.to(device)
    idx_test    = idx_test.to(device)

    # train
    if args.if_train:
        input_data = torch.arange(0, raw_adj.shape[0], 1).to(device)
        save_path = os.path.join(save_dir, 'model.pt')
        best_loss = 1000
        best_acc = -1
        cnt = 0
        for epoch_i in range(args.epochs):
            loss_val, acc_val, loss_test, acc_test = train_one_step(epoch_i, input_data, labels, 
                                                                    norm_adj, norm_adj,
                                                                    idx_train, idx_val, idx_test, 
                                                                    model, optimizer, writer)

            if acc_test >= best_acc:
                if acc_test >= best_acc:
                    best_acc = acc_test
                    # torch.save(model.state_dict(), save_path)

                best_acc = np.max((best_acc, acc_test))
                cnt = 0
            else:
                cnt += 1
                # scheduler.step(acc_val, epoch=epoch_i)

            if cnt == args.patience:
                logging.info(f'Early stop @ Epoch {epoch_i}, loss_val: {loss_val}, acc_val: {acc_val}, '
                f'loss_test: {loss_test}, acc_test: {acc_test}; best_val_loss: {best_loss}, '
                f'best_val_acc: {best_acc}')
                break
        
        logging.info(f"Optimization Finished! best_acc: {best_acc}")

        input_data = torch.arange(0, raw_adj.shape[0], 1).to(device)
        model.load_state_dict(torch.load(save_path))
        model = model.to(device)
        # test(input_data, labels, raw_adj, sp_adj, idx_test, model)
        logging.info(f"best_acc: {best_acc}")
    
    


if __name__ == "__main__":
    main()


    


