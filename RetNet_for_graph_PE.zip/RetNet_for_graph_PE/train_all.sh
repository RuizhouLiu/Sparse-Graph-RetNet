# python main.py --config_path /home/user/RetNet_for_graph/config/chameleon_config.yaml
python main.py --config_path ./config/squirrel_config.yaml
# python main.py --config_path /home/user/RetNet_for_graph/config/texas_config.yaml
# python main.py --config_path /home/user/RetNet_for_graph/config/wisconsin_config.yaml
# python main.py --config_path /home/user/RetNet_for_graph/config/cornell_config.yaml